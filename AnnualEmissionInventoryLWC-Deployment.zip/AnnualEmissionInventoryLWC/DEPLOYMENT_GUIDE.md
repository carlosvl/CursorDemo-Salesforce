# Annual Emission Inventory LWC - Deployment Guide

## 📦 Package Contents

This deployment package contains a complete Lightning Web Component solution for Net Zero Cloud that displays Annual Emission Inventory records with related Carbon Footprints on Account pages.

### Files Included:
- **LWC Component:** `annualEmissionInventoryList/`
  - `annualEmissionInventoryList.js` - Main component logic
  - `annualEmissionInventoryList.html` - Component template
  - `annualEmissionInventoryList.css` - Component styling
  - `annualEmissionInventoryList.js-meta.xml` - Component metadata
  
- **Apex Controller:** 
  - `AnnualEmissionInventoryController.cls` - Data access layer
  - `AnnualEmissionInventoryController.cls-meta.xml` - Controller metadata
  
- **Test Class:**
  - `AnnualEmissionInventoryControllerTest.cls` - Unit tests
  - `AnnualEmissionInventoryControllerTest.cls-meta.xml` - Test metadata

## 🚀 Deployment Instructions

### Option 1: Salesforce CLI Deployment

1. **Extract** this zip file to your Salesforce DX project
2. **Deploy** using Salesforce CLI:
   ```bash
   # Deploy LWC Component
   sf project deploy start -d annualEmissionInventoryList/
   
   # Deploy Apex Classes  
   sf project deploy start -d AnnualEmissionInventoryController.cls
   sf project deploy start -d AnnualEmissionInventoryControllerTest.cls
   ```

### Option 2: Manual Deployment

1. **Extract** the zip file
2. **Copy** the `annualEmissionInventoryList` folder to `force-app/main/default/lwc/`
3. **Copy** the Apex `.cls` files to `force-app/main/default/classes/`
4. **Deploy** using your preferred deployment method

### Option 3: Change Set Deployment

1. **Create** a new Change Set in your source org
2. **Add** the following components:
   - Lightning Web Component: `annualEmissionInventoryList`
   - Apex Class: `AnnualEmissionInventoryController`
   - Apex Class: `AnnualEmissionInventoryControllerTest`
3. **Deploy** to target org

## ⚙️ Post-Deployment Setup

### 1. Add Component to Account Page

1. Navigate to **Setup** → **Lightning App Builder**
2. **Edit** an existing Account record page or create a new one
3. **Drag** the "Annual Emission Inventory List" component to your desired location
4. **Save** and **Activate** the page

### 2. Set Permissions

Ensure users have access to:
- **Annual Emissions Inventory** object (Read access)
- **Carbon Footprint** objects (Read access):
  - `StnryAssetCrbnFtprnt` (Stationary Asset Carbon Footprint)
  - `VehicleAssetCrbnFtprnt` (Vehicle Asset Carbon Footprint)
  - `Scope3CrbnFtprnt` (Scope 3 Carbon Footprint)

## ✨ Features

- **Data Table Display:** Shows Annual Emission Inventory records for the current Account
- **Row Selection:** Click "View Details" button to select a row
- **Carbon Footprints:** Displays related carbon footprint records in beautiful cards
- **Real Data Integration:** Fetches actual data from Net Zero Cloud objects
- **Smart Formatting:** Emission values formatted to 4 decimal places maximum
- **Responsive Design:** Works on desktop and mobile devices
- **Error Handling:** Graceful handling of missing data or permissions

## 🔍 Troubleshooting

### Component Not Visible
- Verify the component is deployed successfully
- Check user permissions for Annual Emissions Inventory object
- Ensure the component is added to the Account page layout

### No Data Displayed
- Verify Account has related Annual Emission Inventory records
- Check field-level security on relevant fields
- Review debug logs for permission or data issues

### Carbon Footprints Not Loading
- Check permissions for carbon footprint objects
- Verify relationships between objects exist
- Component will show sample data if real data is unavailable

## 📋 Requirements

- **Salesforce Edition:** Enterprise, Unlimited, or Developer Edition
- **Net Zero Cloud:** Package must be installed and configured
- **API Version:** 59.0 or higher
- **Lightning Experience:** Required (does not work in Classic)

## 🎯 Success Verification

After deployment, verify:
1. Component appears in Lightning App Builder for Account pages
2. Component displays Annual Emission Inventory records on Account pages  
3. "View Details" buttons work and show carbon footprint cards
4. Emission values are properly formatted
5. No console errors in browser developer tools

---

**📞 Support:** For issues or questions, refer to the project documentation or contact your Salesforce administrator.
